package pe.edu.upeu.chavez;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenfinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
